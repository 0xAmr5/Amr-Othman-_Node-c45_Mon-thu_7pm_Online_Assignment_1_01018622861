/ ASSIGNMENT_1

 
// P1;


//1:
// const x = "123";

// // استخدام (+) للتحويل الفوري إلى رقم وإضافة 7
// const number = +x + 7;

// console.log(number); // الناتج: 130


// 2:

//  var x= null; // جرب تغير دي لـ null أو "" أو undefined

// // علامة التعجب بتقلب القيمة، لو هي falsy بتبقى true
// if (!x) {
//   console.log("Invalid");
// } else {
//   console.log(x);
// }


  //3:
  
//   for (let i = 1; i <= 10; i++) {
//   // لو الرقم زوجي (باقي القسمة على 2 بيساوي صفر)
//   if (i % 2 === 0) {
//     continue; // فوّت اللفة دي وادخل على اللي بعدها
//   }
  
//   console.log(i);
// }


// 4:

// const numbers = [1, 2, 3, 4, 5];

// // تخزين الدالة داخل متغير (Variable)
// const checkEven = (num) => {
//   return num % 2 === 0;
// };

// const evenNumbers = numbers.filter(checkEven);

// console.log(evenNumbers);


// 5:

// const arr1 = [1, 2, 3];
// const arr2 = [4, 5, 6];

// // استخدام الـ Spread Operator (...) لدمج المصفوفتين
// const mergedArray = [...arr1, ...arr2];

// console.log(mergedArray); // Output: [1, 2, 3, 4, 5, 6]


// 6:

// const dayNumber = 7;

// const dayMap = {
//   1: "Sturday",
//   2: "Sunday",
//   3: "Monday",
//   4: "Tuesday",
//   5: "Wednesday",
//   6: "Thursday",
//   7: "Friday",
// };

// const dayName = dayMap[dayNumber] || "Invalid Day";

// console.log(dayName);


// 7:

// const strings = ["a", "ab", "abc"];

// // map بتاخد كل كلمة وبترجع طولها (length)
// const lengths = strings.map(strings = strings.length);

// console.log(lengths); // Output: [3, 5, 7


// 8:

// function Divisible(num){  

//   if (num % 3 === 0 && num % 5 === 0) {
//     return true;
//   } else {
//     return false;
//   }
// }

// //  Test code
// console.log(Divisible(15)); // true
// console.log(Divisible(10));  // false
// console.log(Divisible(30)); // true



// 9:

function square(num) {

  return num **2;
}

console.log(square(5)); // If you change number;then answer be changed

// another examble:
console.log(square(10));
console.log(square(2));
console.log(square(4));
console.log(square(3));



// 10:
// const user = {
 
//   name: "Ahmed",
//   age: 25,
  
// };


// function dataUser({ name, name }) {
//   return `Hello, my name is ${name} and I  ${age}.`;
// }

// console.log(dataUser(user));


// 11:

// function sum(num1, num2) {
//   num1 = 5;
//   num2 = 10;
 
//   return num1 + num2;
// }


// 12:

// function waitThreeSeconds() {

//   return new Promise(resolve => setTimeout(resolve, 3000))
//   .then(() => "Success");
// }

// waitThreeSeconds().then(console.log); 


// 13:

// const numbers = [3, 6, 25, 8, 20];

// function findMax(arr) {

//   return Math.max(...arr);
// }

// console.log(findMax(numbers));



// // 14:

// const user = {
//   name: "John",
//   age: 30,
// };

// function getKeysManual(obj) {
//   const keys = [];

//   for (const key in obj) {
//     keys.push(key);
//   }

//   return keys;
// }

// console.log(getKeysManual(user)); 

// 15:

// const strings = "The quick brown fox";

// function splitString(str) {
//   return str.split(" ");
// }

// console.log(splitString(strings)); 


// ===================================================================


// P2;

// 1;
 
// the difference between forEach and for...of?

// forEach:
// Simple Operations,Functional Style,Easy Index Access

// for...of:
// Supports Break,Supports Async/Await,Better Readability

// =======================================================================

// 2;
// I didn't know that answer

// 3;
//  The main differences between == and ===?

// 1. == (Loose Equality):



// 1. == (Loose Equality):

// Checks Value only.

// Performs Type Coercion (converts types to match if they are different).

// Example: 5 == "5" returns true.

// 2:

// I didn't know this answer

// 3:
// === (Strict Equality):

// Checks Value AND Data Type.

// No conversion happens. Everything must match exactly.

// Example: 5 === "5" returns false.

//4:
// I didn't know this answer

// 5:
// Type Conversion: Manual conversion.

// Type Coercion: Automatic conversion .
